clc; clear; close all;

%% === Numeric joint values ===
q = deg2rad([0; 90; 90; 90]);      % initial joint angles
q_dot = deg2rad([-15; 30; 30; 0]);     % joint velocities (rad/s)

%% === Simulation parameters ===
dt = 0.0001;          % time step (s)
t_target = 6;       % target time (s)

%% === Number of steps to reach target time ===
N = round(t_target / dt);

%% === Time integration to reach target ===
for k = 1:N
    q = q + q_dot * dt;      % update joint angles
  
end

%% === Compute position at target time ===
X_target = 1000*end_effector_FK(q);   % multiply by 1000 for mm

%% === Display result ===
disp(['End-effector position at t = ', num2str(t_target), ' s:']);
disp(['X = ', num2str(X_target(1)), ' mm']);
disp(['Y = ', num2str(X_target(2)), ' mm']);
disp(['Z = ', num2str(X_target(3)), ' mm']);

%% ===== Forward Kinematics Function =====
function p = end_effector_FK(q)
    L1 = 0.06; L2 = 0.04355; L3 = 0.145; L4 = 0.1058; L5 = 0.00000; L6 = 0.1003;
    DH = [ 0, pi/2, L1+L2, q(1);
           L3, pi, 0,      q(2)+pi/2;
           L4+L5, pi, 0,   q(3);
           L6, 0, 0,       q(4)];
    T = eye(4);
    for i = 1:4
        a = DH(i,1); alpha = DH(i,2); d = DH(i,3); th = DH(i,4);
        Ti = [ cos(th), -sin(th)*cos(alpha), sin(th)*sin(alpha), a*cos(th);
               sin(th), cos(th)*cos(alpha), -cos(th)*sin(alpha), a*sin(th);
               0, sin(alpha), cos(alpha), d;
               0, 0, 0, 1];
        T = T * Ti;
    end
    p = T(1:3,4);
    
end
