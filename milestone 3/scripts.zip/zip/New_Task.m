%% ===== 1. EXAMPLE USAGE =====
clc; clear;

% Define Parameters
start_point = [0.1217; 0; 0.1];      % X0
end_point   = [0.1217; 0; 0.2];      % Xf
duration    = 5;                     % Tf
timestep    = 0.1;                   %  Ts
q_guess     = deg2rad([0;70;90;90]); % Initial guess
q_min = deg2rad([-90; -90; -120; -120]);   % lower limits
q_max = deg2rad([ 90;  90;  120;  120]);   % upper limits

% Call the function
trajectory_table = task_traj(start_point, end_point, duration, timestep, q_guess);
% Display the result
disp("=== Trajectory Output Table ===");
disp(trajectory_table);
%% ===== 2. TASK-SPACE + IK + VELOCITY TRAJECTORY FUNCTION ================
function Task_Space = task_traj(X0, Xf, Tf, Ts, q_init)
    % --- Time vector ---
    t_vec = 0:Ts:Tf;
    N = length(t_vec);
    % Pre-allocate memory
    Log = zeros(N, 11);  
    % Columns: x y z  q1 q2 q3 q4  qd1 qd2 qd3 qd4

    q_curr = q_init;

    for k = 1:N
        t = t_vec(k);

        %% ---- Cubic Time Scaling ----
        s    = 3*(t/Tf)^2 - 2*(t/Tf)^3;
        sdot = (6/Tf^2)*t - (6/Tf^3)*t^2;

        %% ---- Task-Space Desired Position & Velocity ----
        Xd = X0 + s * (Xf - X0);
        Vd = sdot * (Xf - X0);

        %% ---- Inverse Kinematics (Newton-Raphson) ----
        q_curr = inverse_kinematics_func(q_curr, Xd);

        %% ---- Compute Jacobian for Velocity IK ----
        J_inv   = inverse_jacobian_matrix(q_curr);
        qdot    = J_inv * Vd;

        %% ---- Log Data ----
        Log(k,:) = [Xd', q_curr', qdot'];
    end
    %% ---- Convert to Output Table ----
    Task_Space = array2table([t_vec' Log], ...
        'VariableNames', {'Time','x','y','z', ...
        'q1','q2','q3','q4', ...
        'qd1','qd2','qd3','qd4'});
end
%% =========================  INVERSE KINEMATICS  ==========================
function q = inverse_kinematics_func(q0, X)
    tolerance = 1e-4;
    max_iter  = 100;
    alpha     = 0.3;

    q = q0;

    % ===== Joint Limits =====
    q_min = deg2rad([-90; -90; -120; -120]);
    q_max = deg2rad([ 90;  90;  120;  120]);

    for k = 1:max_iter
        F = forward_kinematics_func(q) - X;
        if norm(F) < tolerance
            break;
        end

        J_inv = inverse_jacobian_matrix(q);
        q = q - alpha * J_inv * F;

        % --- Apply joint limits ---
        q = max(q_min, min(q, q_max));
    end
end
%% =========================  FORWARD KINEMATICS  ==========================
function X = forward_kinematics_func(q)
    % Robot link lengths
    L1 = 0.06; L2 = 0.04355; L3 = 0.145;
    L4 = 0.1058; L5 = 0.034; L6 = 0.1003;

    DH = [ 0,     pi/2, L1+L2, q(1);
           L3,    pi,   0,     q(2)+pi/2;
           L4+L5, pi,   0,     q(3);
           L6,    0,    0,     q(4)];

    T = eye(4);

    for i = 1:4
        a = DH(i,1); alpha = DH(i,2); d = DH(i,3); th = DH(i,4);
        Ti = [cos(th), -sin(th)*cos(alpha),  sin(th)*sin(alpha), a*cos(th);
              sin(th),  cos(th)*cos(alpha), -cos(th)*sin(alpha), a*sin(th);
              0,        sin(alpha),          cos(alpha),         d;
              0,        0,                   0,                  1];
        T = T * Ti;
    end

    X = T(1:3,4);
end

%% =====================  NUMERICAL INVERSE JACOBIAN  ======================
function J_inv = inverse_jacobian_matrix(q)
    delta = 1e-6;
    n     = length(q);

    J  = zeros(3,n);
    X0 = forward_kinematics_func(q);

    for i = 1:n
        dq = q;
        dq(i) = dq(i) + delta;
        X1 = forward_kinematics_func(dq);
        J(:,i) = (X1 - X0) / delta;
    end

    J_inv = pinv(J);
end
