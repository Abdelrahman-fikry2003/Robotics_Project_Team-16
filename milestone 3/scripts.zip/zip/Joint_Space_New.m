%% ===================== EXAMPLE USAGE =====================
clc; clear;

% --- Define initial and final end-effector positions ---
X0 = [0.1217; 0; 0.1];   % initial position
Xf = [0.1217; 0; 0.2];   % final position
Tf = 5;                   % total motion time
Ts = 0.1;                 % sampling time

% --- Initial guess for IK (within reasonable limits) ---
q_guess = deg2rad([0; 70; 90; 90]);  % safe starting angles

% --- Compute initial and final joint angles using inverse kinematics ---
q0 = inverse_kinematics_func(q_guess, X0);   % initial joints
qf = inverse_kinematics_func(q0, Xf);        % final joints

% --- Set initial and final joint velocities (zero for cubic polynomial) ---
qdot0 = zeros(size(q0));
qdotf = zeros(size(qf));

% --- Generate joint-space trajectory ---
Joint_Space = joint_traj(q0, qf, qdot0, qdotf, Tf, Ts);

% --- Compute end-effector positions for each joint configuration ---
N = size(Joint_Space,1);
EE_Positions = zeros(N,3);

for k = 1:N
    EE_Positions(k,:) = forward_kinematics_func(Joint_Space(k,:)')';
end

% --- Display results ---
disp("=== Joint-Space Trajectory (degrees) ===");
disp(Joint_Space);  % convert to degrees for clarity

disp("=== End-Effector Positions (meters) ===");
disp(array2table([0:Ts:Tf; EE_Positions']', 'VariableNames', {'Time','X','Y','Z'}));

%% ===================== JOINT-SPACE TRAJECTORY FUNCTION =====================
function Joint_Space = joint_traj(q0, qf, qdot0, qdotf, Tf, Ts)
    n = length(q0);
    t = 0:Ts:Tf;
    N = length(t);
    Joint_Space = zeros(N, n);

    for j = 1:n
        % Cubic polynomial coefficients for joint j
        a0 = q0(j);
        a1 = qdot0(j);
        a2 = (3*(qf(j)-q0(j))/Tf^2) - (2*qdot0(j)+qdotf(j))/Tf;
        a3 = (-2*(qf(j)-q0(j))/Tf^3) + (qdot0(j)+qdotf(j))/Tf^2;

        % Evaluate polynomial at each time step
        for k = 1:N
            tk = t(k);
            Joint_Space(k,j) = a0 + a1*tk + a2*tk^2 + a3*tk^3;
        end
    end
end

%% ===================== FORWARD KINEMATICS FUNCTION =====================
function X = forward_kinematics_func(q)
    L1 = 0.06; L2 = 0.04355; L3 = 0.145;
    L4 = 0.1058; L5 = 0.034; L6 = 0.1003;

    DH = [ 0, pi/2, L1+L2, q(1);
           L3, pi,   0,     q(2)+pi/2;
           L4+L5, pi, 0,     q(3);
           L6, 0,    0,      q(4)];

    T = eye(4);
    for i = 1:4
        a = DH(i,1); alpha = DH(i,2); d = DH(i,3); th = DH(i,4);
        Ti = [cos(th), -sin(th)*cos(alpha), sin(th)*sin(alpha), a*cos(th);
              sin(th),  cos(th)*cos(alpha), -cos(th)*sin(alpha), a*sin(th);
              0,        sin(alpha),         cos(alpha),         d;
              0,        0,                  0,                  1];
        T = T * Ti;
    end
    X = T(1:3,4);
end

%% ===================== INVERSE KINEMATICS FUNCTION =====================
function q = inverse_kinematics_func(q0, X)
    tolerance = 1e-4;
    max_iter = 100;
    alpha = 0.3;
    q = q0;

    % --- Joint Limits (radians) ---
    q_min = deg2rad([0; 0; 0; 0]);      % minimum angles for joints
    q_max = deg2rad([180; 180; 180; 180]); % maximum angles for joints

    for k = 1:max_iter
        F = forward_kinematics_func(q) - X;
        if norm(F) < tolerance
            break;
        end
        J_inv = inverse_jacobian_matrix(q);
        q = q - alpha * J_inv * F;

        % --- Clamp angles to limits ---
        q = max(q_min, min(q, q_max));
    end
end

%% ===================== NUMERICAL INVERSE JACOBIAN =====================
function J_inv = inverse_jacobian_matrix(q)
    delta = 1e-6;
    n = length(q);
    J = zeros(3,n);
    X0 = forward_kinematics_func(q);

    for i = 1:n
        dq = q;
        dq(i) = dq(i) + delta;
        X1 = forward_kinematics_func(dq);
        J(:,i) = (X1 - X0)/delta;
    end

    J_inv = pinv(J);
end
